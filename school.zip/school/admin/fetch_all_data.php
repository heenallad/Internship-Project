<?php
session_start();
header('Content-Type: application/json');

// Ensure user is logged in and has the correct role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  echo json_encode([]);
  exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}
include 'db.php'; // Make sure your DB connection is established

// Step 1: Get all schools
$sql = "SELECT id, name FROM schools ORDER BY name";
$result = $conn->query($sql);
$schools = [];

while ($school = $result->fetch_assoc()) {
  $school_id = $school['id'];

  // Step 2: Get work items for each school
  $work_items_sql = "
    SELECT id, title, start_date, end_date
    FROM work_items 
    WHERE school_id = $school_id 
    ORDER BY title
  ";

  $work_items_result = $conn->query($work_items_sql);

  $work_items = [];

  while ($work_item = $work_items_result->fetch_assoc()) {
    $work_item_id = $work_item['id'];

    // Step 3: Get subtasks for each work item
    $subtasks_sql = "SELECT title, is_done, remarks FROM item_subtasks WHERE work_item_id = $work_item_id";
    $subtasks_result = $conn->query($subtasks_sql);

    $completed = [];
    $pending = [];
    $remarks = [];

    while ($subtask = $subtasks_result->fetch_assoc()) {
      if ($subtask['is_done']) {
        $completed[] = $subtask['title'];
        $remarks[] = $subtask['remarks'] ?? '';
      } else {
        $pending[] = $subtask['title'];
      }
    }

    $total_subtasks = count($completed) + count($pending);
    $completed_count = count($completed);
    $pending_count = count($pending);

    $work_items[] = [
      'title' => $work_item['title'],
      'start_date' => $work_item['start_date'],
      'end_date' => $work_item['end_date'],
      'total' => $total_subtasks,
      'completed' => $completed_count,
      'pending' => $pending_count,
      'completed_titles' => $completed,
      'pending_titles' => $pending,
      'remarks' => $remarks
    ];
  }

  // Step 4: Add all work items for each school
  $schools[] = [
    'school_name' => $school['name'],
    'work_items' => $work_items
  ];
}

// Return data as JSON
echo json_encode($schools);
?>