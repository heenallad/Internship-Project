<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}

include 'db.php';

$sql = "SELECT wi.id AS work_item_id, wi.title AS work_title, st.title AS subtask_title
        FROM work_items wi
        LEFT JOIN item_subtasks st ON wi.id = st.work_item_id
        ORDER BY wi.id, st.id";

$result = $conn->query($sql);

$prevWorkId = null;
$srNo = 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Category-Based Report (Admin)</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css">
  <style>
    body {
      background-color: #f8f9fa;
      padding: 40px;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    .table-container {
      max-width: 90%;
      margin: auto;
    }
  </style>
  <script>
    // Disable Right-Click
    document.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    });

    // Disable DevTools Shortcut Keys
    document.addEventListener("keydown", function(e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
      }
    });

    // Optional: Detect if DevTools is open (basic)
    setInterval(function() {
      if (window.outerHeight - window.innerHeight > 200) {
        document.body.innerHTML = "<h1>Inspect Disabled</h1>";
      }
    }, 1000);
  </script>
</head>

<body>
  <div class="table-container">
    <a href="index.php" class="btn btn-outline-dark">← Back to Dashboard</a>
    <h2>📋 Work-Category Report</h2>
    <table id="workTable" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>Sr No</th>
          <th>Work Title</th>
          <th>Subtask Title</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $srNo++ ?></td>
            <td>
              <?php
              if ($row['work_item_id'] !== $prevWorkId) {
                echo htmlspecialchars($row['work_title']);
                $prevWorkId = $row['work_item_id'];
              }
              ?>
            </td>
            <td><?= htmlspecialchars($row['subtask_title'] ?? '—') ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>

  <script>
    $(document).ready(function() {
      $('#workTable').DataTable({
        dom: 'Bfrtip',
        buttons: ['excel', 'pdf', 'print']
      });
    });
  </script>
</body>

</html>