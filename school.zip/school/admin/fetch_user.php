<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}

include 'db.php';

$user_id = intval($_POST['user_id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode(['error' => 'Invalid user ID']);
    exit;
}

// Fetch user basic info
$stmt = $conn->prepare("SELECT id, employee_name, username FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(['error' => 'User not found']);
    exit;
}

// Fetch assigned schools for user
$stmt2 = $conn->prepare("SELECT school_id FROM user_school WHERE user_id = ?");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$res2 = $stmt2->get_result();

$schools = [];
while ($row = $res2->fetch_assoc()) {
    $schools[] = $row['school_id'];
}

$response = [
    'id' => $user['id'],
    'employee_name' => $user['employee_name'],
    'username' => $user['username'],
    'schools' => $schools,
];

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
