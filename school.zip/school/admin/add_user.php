<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}

include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add / Edit User - Admin Panel</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Select2 CSS (Bootstrap theme) -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.3.2/dist/select2-bootstrap4.min.css" rel="stylesheet">

    <script>
        // Disable Right-Click
        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
        });

        // Disable DevTools Shortcut Keys
        document.addEventListener("keydown", function(e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) {
                e.preventDefault();
            }
        });

        // Optional: Detect if DevTools is open (basic)
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > 200) {
                document.body.innerHTML = "<h1>Inspect Disabled</h1>";
            }
        }, 1000);
    </script>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .logout-link {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }

        .select2-container--bootstrap5 .select2-selection {
            min-height: 38px;
            border-radius: 0.375rem;
            border: 1px solid #ced4da;
        }

        .card {
            border-radius: 0.75rem;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        h3 {
            font-weight: 600;
            color: #343a40;
        }

        label.form-label {
            font-weight: 500;
            color: #495057;
        }

        #msgBox .alert {
            font-weight: 500;
            font-size: 0.95rem;
        }

        #addUserBtn {
            min-width: 140px;
            font-weight: 600;
            letter-spacing: 0.03em;
        }

        /* Smooth transition on form inputs */
        input.form-control,
        select.form-select {
            transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }

        input.form-control:focus,
        select.form-select:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 6px rgba(13, 110, 253, 0.25);
            outline: none;
        }
    </style>
</head>

<body>
    <div class="container py-5">
        <a href="index.php" class="btn btn-secondary mb-4">← Back to Dashboard</a>
        <a href="../logout.php" class="btn btn-danger logout-link">Logout</a>

        <h3 class="mb-4">Add / Edit User and Assign Schools</h3>

        <!-- Select User to Edit -->
        <div class="mb-4">
            <label class="form-label">Select User to Edit</label>
            <select id="editUserSelect" class="form-select">
                <option value="">-- Add New User --</option>
                <?php
                $users = $conn->query("SELECT id, employee_name FROM users ORDER BY employee_name");
                while ($user = $users->fetch_assoc()) {
                    echo "<option value='{$user['id']}'>" . htmlspecialchars($user['employee_name']) . "</option>";
                }
                ?>
            </select>
        </div>

        <!-- User Form -->
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-4">
                        <label class="form-label">Employee Name</label>
                        <input type="text" id="employee_name" class="form-control" placeholder="Enter employee name" style="text-transform: uppercase;">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Username</label>
                        <input type="text" id="username" class="form-control" placeholder="Enter username">
                    </div>

                    <div class="col-md-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" class="form-control" placeholder="Enter password (leave blank to keep)">
                        <div id="password-error" style="color: red; font-size: 0.9em; margin-top: 5px;"></div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Assign School(s)</label>
                        <select id="schoolSelect" class="form-select selectpicker" name="schools[]" multiple>
                            <?php
                            $schools = $conn->query("SELECT * FROM schools ORDER BY name");
                            while ($school = $schools->fetch_assoc()) {
                                echo "<option value='{$school['id']}'>" . htmlspecialchars($school['name']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-12 text-end">
                        <button class="btn btn-success" id="addUserBtn">Add User</button>
                    </div>
                </div>

                <div id="msgBox" class="mt-3"></div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

    <!-- Bootstrap Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Select2 -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            const passwordInput = document.getElementById('password');
            const errorDiv = document.getElementById('password-error');

            passwordInput.addEventListener('blur', function() {
                const password = passwordInput.value;

                // Skip validation if left blank (optional behavior)
                if (password === '') {
                    errorDiv.textContent = '';
                    return;
                }

                const pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8}$/;

                if (!pattern.test(password)) {
                    errorDiv.textContent = 'Password must be exactly 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&).';
                    passwordInput.classList.add('is-invalid');
                } else {
                    errorDiv.textContent = '';
                    passwordInput.classList.remove('is-invalid');
                }
            });

            document.getElementById("employee_name").addEventListener("input", function() {
                this.value = this.value.toUpperCase();
            });

            $('#schoolSelect').select2({
                theme: 'bootstrap4',
                placeholder: "Select one or more schools",
                width: '100%'
            });

            let editMode = false;
            let editUserId = null;

            // When user selects an existing user to edit
            $('#editUserSelect').change(function() {
                const userId = $(this).val();

                if (!userId) {
                    // Clear form for new user
                    editMode = false;
                    editUserId = null;
                    $('#employee_name, #username, #password').val('');
                    $('#schoolSelect').val(null).trigger('change');
                    $('#addUserBtn').text('Add User');
                    $('#msgBox').html('');
                    return;
                }

                // Fetch user info for editing from fetch_user.php
                $.post('fetch_user.php', {
                    user_id: userId
                }, function(res) {
                    if (res.error) {
                        $('#msgBox').html('<div class="alert alert-danger">' + res.error + '</div>');
                        return;
                    }
                    $('#employee_name').val(res.employee_name);
                    $('#username').val(res.username);
                    $('#password').val(''); // Password blank for security
                    $('#schoolSelect').val(res.schools).trigger('change');

                    editMode = true;
                    editUserId = userId;
                    $('#addUserBtn').text('Update User');
                    $('#msgBox').html('');
                }, 'json').fail(function() {
                    $('#msgBox').html('<div class="alert alert-danger">Failed to fetch user data.</div>');
                });
            });

            $('#addUserBtn').click(function() {
                const employee_name = $('#employee_name').val().trim();
                const username = $('#username').val().trim();
                const password = $('#password').val();
                const schools = $('#schoolSelect').val();

                if (!employee_name || !username || !schools || !schools.length) {
                    $('#msgBox').html('<div class="alert alert-danger">Please fill all fields and select at least one school.</div>');
                    return;
                }

                if (!editMode && !password) {
                    $('#msgBox').html('<div class="alert alert-danger">Password is required for new users.</div>');
                    return;
                }

                let postData = {
                    employee_name: employee_name,
                    username: username,
                    password: password,
                    schools: schools,
                    op: editMode ? 'update_user' : 'add_user'
                };

                if (editMode) {
                    postData.user_id = editUserId;
                }

                $.post('process.php', postData, function(res) {
                    if (res === 'ok') {
                        $('#msgBox').html('<div class="alert alert-success">User ' + (editMode ? 'updated' : 'added') + ' successfully.</div>');

                        if (!editMode) {
                            $('#employee_name, #username, #password').val('');
                            $('#schoolSelect').val(null).trigger('change');
                        } else {
                            // Optionally refresh user list in dropdown
                            // For now just update button text
                            $('#addUserBtn').text('Update User');
                        }
                    } else {
                        $('#msgBox').html('<div class="alert alert-danger">' + res + '</div>');
                    }
                });
            });
        });
    </script>
</body>

</html>