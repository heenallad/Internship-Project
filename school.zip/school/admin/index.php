<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}
?>

<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en" x-data="{ sidebarOpen: true, reportOpen: false }" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="UTF-8" />
    <title>Admin - School Work Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs" defer></script>
    <script>
        // Disable Right-Click
        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
        });

        // Disable DevTools Shortcut Keys
        document.addEventListener("keydown", function(e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) {
                e.preventDefault();
                
            }
        });

        // Optional: Detect if DevTools is open (basic)
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > 200) {
                document.body.innerHTML = "<h1>Inspect Disabled</h1>";
            }
        }, 1000);
    </script>
</head>

<body class="bg-gradient-to-br from-gray-100 to-gray-300 min-h-screen text-gray-800">

    <!-- ✅ Alpine.js CDN -->
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <!-- 🌙 Sidebar with Modal Trigger -->
    <div class="flex min-h-screen bg-gray-100" x-data="{ reportOpen: false }">
        <!-- Sidebar -->
        <aside x-show="sidebarOpen" class="w-64 bg-gray-900 text-white flex-shrink-0 px-6 py-8 shadow-lg transition-transform duration-300"
            x-transition:enter="transform ease-out duration-200"
            x-transition:enter-start="-translate-x-full"
            x-transition:enter-end="translate-x-0"
            x-transition:leave="transform ease-in duration-200"
            x-transition:leave-start="translate-x-0"
            x-transition:leave-end="-translate-x-full">
            <h2 class="text-2xl font-bold mb-8">Admin Panel</h2>

            <!-- Navigation -->
            <nav class="space-y-4">
                <a href="index.php" class="flex items-center gap-2 px-3 py-2 rounded bg-blue-600 hover:bg-blue-700 transition">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="add_user.php" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-700 transition">
                    <i class="fas fa-user-plus"></i> Add User
                </a>
                <button @click="reportOpen = true"
                    class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-700 transition w-full text-left">
                    <i class="fa fa-file-text"></i> Report
                </button>
                <a href="edit_task.php" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-700 transition">
                    <i class="fa fa-pencil"></i> Edit Tasks
                </a>
                <a href="all_reports.php"
                    class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-700 transition">
                    <i class="fa fa-file-alt"></i> All Reports
                </a>
                <a href="../logout.php"
                    class="flex items-center gap-2 px-3 py-2 rounded bg-red-600 hover:bg-red-700 text-white font-medium transition">
                    Logout
                </a>
            </nav>
        </aside>

        <!-- ✅ Modal -->
        <div x-show="reportOpen"
            x-transition
            class="fixed inset-0 flex items-center justify-center z-50"
            style="display: none;">
            <!-- Overlay -->
            <div class="fixed inset-0 bg-black bg-opacity-50" @click="reportOpen = false"></div>

            <!-- Modal Box -->
            <div class="relative bg-white w-full max-w-xl mx-auto p-6 rounded-lg shadow-lg z-50">
                <h2 class="text-2xl font-semibold mb-4 text-gray-800">Type of Report</h2>

                <div class="space-y-4">
                    <a href="report1.php" class="block w-full text-center bg-green-600 hover:bg-green-700 text-white py-2 rounded transition">
                        USER-ASSIGNED SCHOOL
                    </a>
                    <a href="report2.php" class="block w-full text-center bg-red-600 hover:bg-red-700 text-white py-2 rounded transition">
                        CATEGORY BASED
                    </a>
                    <a href="report3.php" class="block w-full text-center bg-blue-500 hover:bg-blue-600 text-white py-2 rounded transition">
                        SCHOOL-ASSIGNED TASK
                    </a>
                </div>

                <button @click="reportOpen = false"
                    class="absolute top-2 right-2 text-gray-500 hover:text-red-600 text-xl font-bold">
                    &times;
                </button>
            </div>
        </div>



        <!-- Main Content -->
        <main class="flex-1 p-10">
            <!-- Toggle Button -->
            <button @click="sidebarOpen = !sidebarOpen"
                class="mb-4 px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition">≡
                <!-- Toggle Sidebar -->
            </button>

            <h1 class="text-3xl font-bold text-center text-gray-800 mb-8">Admin Dashboard</h1>

            <!-- Add Sections -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
                <!-- Add School -->
                <div class="bg-white p-6 rounded shadow">
                    <h2 class="text-lg font-semibold text-gray-700 mb-4">Add School</h2>
                    <div class="flex gap-2">
                        <input id="newSchool" type="text" placeholder="Enter School Name"
                            class="w-full border px-4 py-2 rounded uppercase focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <button id="addSchoolBtn"
                            class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Add</button>
                    </div>
                </div>

                <!-- Add Work Title -->
                <div class="bg-white p-6 rounded shadow">
                    <h2 class="text-lg font-semibold text-gray-700 mb-4">Add Work Title</h2>
                    <div class="space-y-2">
                        <select id="schoolForWork"
                            class="w-full border px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                            <option value="">Select School</option>
                        </select>
                        <input id="newWorkItem" type="text" placeholder="Work Title"
                            class="w-full border px-4 py-2 rounded uppercase focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <button id="addWorkBtn"
                            class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Add</button>
                    </div>
                </div>

                <!-- Add Subtask -->
                <div class="bg-white p-6 rounded shadow">
                    <h2 class="text-lg font-semibold text-gray-700 mb-4">Add Subtask</h2>
                    <div class="space-y-2">
                        <select id="schoolSelect"
                            class="w-full border px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                            <option value="">Select School</option>
                        </select>
                        <select id="workSelect"
                            class="w-full border px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                            <option value="">Select Work</option>
                        </select>
                        <div class="flex gap-2">
                            <input id="newSubtaskTitle" type="text" placeholder="Subtask"
                                class="w-full border px-4 py-2 rounded uppercase focus:outline-none focus:ring-2 focus:ring-blue-400">
                            <button id="addSubtaskBtn"
                                class="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded">Add</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="max-w-6xl mx-auto bg-white p-6 rounded shadow">
                <!-- Tabs -->
                <nav class="flex space-x-4 border-b pb-4 mb-4">
                    <button class="tab-btn text-blue-600 font-semibold" data-tab="schoolsTab">Schools</button>
                    <button class="tab-btn text-gray-600 hover:text-blue-600" data-tab="worksTab">Work Items</button>
                    <button class="tab-btn text-gray-600 hover:text-blue-600" data-tab="subtasksTab">Subtasks</button>
                </nav>

                <!-- Filters -->
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <label for="entriesPerPage" class="mr-2 font-medium">Show</label>
                        <select id="entriesPerPage" class="border rounded px-2 py-1">
                            <option value="5">5</option>
                            <option value="10" selected>10</option>
                            <option value="15">15</option>
                            <option value="20">20</option>
                        </select>
                        <span class="ml-1">entries per page</span>
                    </div>
                    <input type="text" id="searchInput" placeholder="Search..." class="border rounded px-3 py-1">
                </div>

                <!-- Tab Content -->
                <div id="schoolsTab" class="tab-content">
                    <table class="w-full text-left border">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3">#</th>
                                <th class="p-3">School Name</th>
                                <th class="p-3">Action</th>
                            </tr>
                        </thead>
                        <tbody id="schoolTable">
                            <!-- Example rows -->
                            <tr>
                                <td class="p-3">1</td>
                                <td class="p-3">Greenwood High</td>
                                <td class="p-3">Edit</td>
                            </tr>
                            <tr>
                                <td class="p-3">2</td>
                                <td class="p-3">Springdale School</td>
                                <td class="p-3">Edit</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div id="worksTab" class="tab-content hidden">
                    <table class="w-full text-left border">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3">#</th>
                                <th class="p-3">Work Title</th>
                                <th class="p-3">Action</th>
                            </tr>
                        </thead>
                        <tbody id="workTable">
                            <tr>
                                <td class="p-3">1</td>
                                <td class="p-3">Math Revision</td>
                                <td class="p-3">Edit</td>
                            </tr>
                            <tr>
                                <td class="p-3">2</td>
                                <td class="p-3">Science Project</td>
                                <td class="p-3">Edit</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div id="subtasksTab" class="tab-content hidden">
                    <table class="w-full text-left border">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3">#</th>
                                <th class="p-3">Subtask Title</th>
                                <th class="p-3">Action</th>
                            </tr>
                        </thead>
                        <tbody id="subtaskTable">
                            <tr>
                                <td class="p-3">1</td>
                                <td class="p-3">Buy supplies</td>
                                <td class="p-3">Edit</td>
                            </tr>
                            <tr>
                                <td class="p-3">2</td>
                                <td class="p-3">Prepare slides</td>
                                <td class="p-3">Edit</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    </div>

    <!-- JS: Tabs logic -->
    <script>
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');
        const searchInput = document.getElementById('searchInput');
        const entriesPerPage = document.getElementById('entriesPerPage');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                tabButtons.forEach(btn => btn.classList.remove('text-blue-600', 'font-semibold'));
                button.classList.add('text-blue-600', 'font-semibold');

                tabContents.forEach(tab => tab.classList.add('hidden'));
                document.getElementById(button.dataset.tab).classList.remove('hidden');

                filterTables();
            });
        });

        searchInput.addEventListener('input', filterTables);
        entriesPerPage.addEventListener('change', filterTables);

        function filterTables() {
            const search = searchInput.value.toLowerCase();
            const maxRows = parseInt(entriesPerPage.value);
            const activeTab = [...tabContents].find(tab => !tab.classList.contains('hidden'));
            const tbody = activeTab.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));

            let shown = 0;
            rows.forEach(row => {
                const matches = row.textContent.toLowerCase().includes(search);
                if (matches && shown < maxRows) {
                    row.style.display = '';
                    shown++;
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Trigger filter on load
        filterTables();
    </script>

    <!-- Bootstrap & jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.querySelectorAll('.uppercase-input').forEach(function(input) {
            input.addEventListener('input', function() {
                this.value = this.value.toUpperCase();
            });
        });

        // Load schools into selects and table
        function loadSchools() {
            $.post('process.php', {
                op: 'list_schools'
            }, data => {
                const schools = JSON.parse(data);
                let options = '<option value="">Select School</option>';
                schools.forEach(s => options += `<option value="${s.id}">${s.name}</option>`);
                $('#schoolForWork, #schoolSelect').html(options);

                // Render schools in table
                let schoolRows = schools.map((s, i) => `
                        <tr data-id="${s.id}">
                            <td>${i + 1}</td>
                            <td>
                                <span class="text">${s.name}</span>
                                <input type="text" class="form-control edit" value="${s.name}" />
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-btn">Edit</button>
                                <button class="btn btn-sm btn-success save-btn">Save</button>
                            </td>
                        </tr>
                    `).join('');
                $('#schoolTable').html(schoolRows);
                $('.save-btn').hide(); // hide save buttons initially
                $('.edit').hide(); // hide inputs initially
            });
        }

        // Load work items table and dropdown based on school
        function loadWorkItems(schoolId = '') {
            $.post('process.php', {
                op: schoolId ? 'list_work_items' : 'list_all_work_items',
                school_id: schoolId
            }, data => {
                const works = JSON.parse(data);
                let options = '<option value="">Select Work</option>';
                works.forEach(w => options += `<option value="${w.id}">${w.title}</option>`);
                $('#workSelect').html(options);

                // Render works in table
                let workRows = works.map((w, i) => `
                        <tr data-id="${w.id}">
                            <td>${i + 1}</td>
                            <td>
                                <span class="text">${w.title}</span>
                                <input type="text" class="form-control edit" value="${w.title}" />
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-btn">Edit</button>
                                <button class="btn btn-sm btn-success save-btn">Save</button>
                            </td>
                        </tr>
                    `).join('');
                $('#workTable').html(workRows);
                $('.save-btn').hide();
                $('.edit').hide();
            });
        }

        // Load subtasks table and dropdown based on school
        function loadSubtasks(schoolId = '') {
            $.post('process.php', {
                op: schoolId ? 'list_subtasks_by_school' : 'list_all_subtasks',
                school_id: schoolId
            }, data => {
                const subs = JSON.parse(data);

                // Render subtasks in table
                let subRows = subs.map((s, i) => `
                        <tr data-id="${s.id}">
                            <td>${i + 1}</td>
                            <td>
                                <span class="text">${s.title}</span>
                                <input type="text" class="form-control edit" value="${s.title}" />
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-btn">Edit</button>
                                <button class="btn btn-sm btn-success save-btn">Save</button>
                            </td>
                        </tr>
                    `).join('');
                $('#subtaskTable').html(subRows);
                $('.save-btn').hide();
                $('.edit').hide();
            });
        }

        $(function() {
            // Initial load
            loadSchools();
            loadWorkItems();
            loadSubtasks();

            // Add new school
            $('#addSchoolBtn').click(() => {
                const name = $('#newSchool').val().trim();
                if (!name) return alert('Please enter a school name.');
                $.post('process.php', {
                    op: 'add_school',
                    name
                }, res => {
                    if (res === 'ok') {
                        alert('School added successfully.');
                        $('#newSchool').val('');
                        loadSchools();
                    } else alert(res);
                });
            });

            // Add new work item
            $('#addWorkBtn').click(() => {
                const schoolId = $('#schoolForWork').val();
                const title = $('#newWorkItem').val().trim();
                if (!schoolId) return alert('Please select a school.');
                if (!title) return alert('Please enter work title.');
                $.post('process.php', {
                    op: 'add_work_item',
                    school_id: schoolId,
                    title
                }, res => {
                    if (res === 'ok') {
                        alert('Work item added successfully.');
                        $('#newWorkItem').val('');
                        loadWorkItems(schoolId);
                        loadSubtasks(schoolId);
                    } else alert(res);
                });
            });

            // Update workSelect dropdown when schoolSelect changes (for subtasks)
            $('#schoolSelect').change(function() {
                const sid = $(this).val();
                $('#workSelect').html('<option value="">Select Work</option>');
                if (sid) {
                    loadWorkItems(sid);
                    loadSubtasks(sid);
                } else {
                    loadWorkItems();
                    loadSubtasks();
                }
            });

            // Add new subtask
            $('#addSubtaskBtn').click(() => {
                const workId = $('#workSelect').val();
                const title = $('#newSubtaskTitle').val().trim();
                if (!workId) return alert('Please select a work item.');
                if (!title) return alert('Please enter a subtask title.');
                $.post('process.php', {
                    op: 'add_subtask',
                    work_id: workId,
                    title
                }, res => {
                    if (res === 'ok') {
                        alert('Subtask added successfully.');
                        $('#newSubtaskTitle').val('');
                        // Reload subtasks for selected school
                        const sid = $('#schoolSelect').val();
                        loadSubtasks(sid);
                    } else alert(res);
                });
            });

            // Handle Edit button click
            $(document).on('click', '.edit-btn', function() {
                const row = $(this).closest('tr');
                row.find('.text').hide();
                row.find('.edit').show();
                $(this).hide();
                row.find('.save-btn').show();
            });

            // Handle Save button click
            $(document).on('click', '.save-btn', function() {
                const row = $(this).closest('tr');
                const id = row.data('id');
                const newValue = row.find('.edit').val().trim();
                if (!newValue) return alert('Value cannot be empty.');

                // Determine operation by table id
                let op = '';
                if (row.closest('tbody').attr('id') === 'schoolTable') op = 'update_school';
                else if (row.closest('tbody').attr('id') === 'workTable') op = 'update_work';
                else if (row.closest('tbody').attr('id') === 'subtaskTable') op = 'update_subtask';

                $.post('process.php', {
                    op,
                    id,
                    title: newValue,
                    name: newValue
                }, res => {
                    if (res === 'ok') {
                        alert('Update successful.');
                        // Reload all tables to keep data consistent
                        loadSchools();
                        loadWorkItems();
                        loadSubtasks();
                    } else {
                        alert('Update failed: ' + res);
                    }
                });
            });
        });
    </script>
</body>

</html>