<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>User Activity – Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
     <script>
    // Disable Right-Click
    document.addEventListener("contextmenu", function (e) {
      e.preventDefault();
    });

    // Disable DevTools Shortcut Keys
    document.addEventListener("keydown", function (e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
        alert("This Is Production Site F12 key and right chick is off");
      }
    });

    // Optional: Detect if DevTools is open (basic)
    setInterval(function () {
      if (window.outerHeight - window.innerHeight > 200) {
        document.body.innerHTML = "<h1>Inspect Disabled</h1>";
      }
    }, 1000);
    
  </script>
  
    <style>
        body {
            background-color: #f8f9fa;
        }

        .logout-link {
            position: fixed;
            top: 1em;
            right: 1em;
            background: #dc3545;
            color: white;
            padding: 0.5em 1.2em;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 0.4em;
            text-decoration: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
            transition: background-color 0.2s ease;
            z-index: 999;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <!-- <div class="col-md-3 col-lg-2 bg-dark border-end min-vh-100 p-3">
        <h4 class="mb-4 text-white">Admin Panel</h4>
        <ul class="nav nav-pills flex-column">
          <li class="nav-item">
            <a href="index.php" class="nav-link text-white">
              <i class="fas fa-home"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a href="add_user.php" class="nav-link text-white">
              <i class="fas fa-user-plus"></i> Add User
            </a>
          </li>
          <li class="nav-item">
            <a href="user_activity.php" class="nav-link active text-white">
              <i class="fas fa-chart-line"></i> User Activity
            </a>
          </li>
        </ul>
        <a href="../logout.php" class="btn btn-danger w-100 mt-4">Logout</a>
      </div> -->
<!-- 
            <a href="index.php" class="btn btn-secondary mb-4">← Back to Dashboard</a>
            <a href="../logout.php" class="logout-link" aria-label="Logout from user panel">Logout</a> -->
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                    <a href="index.php" class="btn btn-secondary mb-4">← Back to Dashboard</a>
                    <a href="../logout.php" class="logout-link" aria-label="Logout from user panel">Logout</a>

                <h2 class="mb-4">User Activity</h2>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle">
                        <thead class="table-secondary">
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Assigned Schools</th>
                                <th>Work Items Created</th>
                                <th>Subtasks Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "
                SELECT 
                  u.id, u.employee_name,
                  GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS schools,
                  COUNT(DISTINCT w.id) AS work_count,
                  COUNT(DISTINCT st.id) AS subtask_count
                FROM users u
                LEFT JOIN user_school us ON us.user_id = u.id
                LEFT JOIN schools s ON s.id = us.school_id
                LEFT JOIN work_items w ON w.created_by = u.id
                LEFT JOIN item_subtasks st ON st.created_by = u.id
                GROUP BY u.id, u.employee_name
                ORDER BY u.employee_name
              ";
                            $res = $conn->query($sql);
                            $i = 0;
                            while ($row = $res->fetch_assoc()):
                                $i++;
                            ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= htmlspecialchars($row['employee_name']) ?></td>
                                    <td><?= htmlspecialchars($row['schools'] ?: '—') ?></td>
                                    <td><?= $row['work_count'] ?></td>
                                    <td><?= $row['subtask_count'] ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>