<?php
include 'db.php';

$op = $_POST['op'] ?? '';
$response = '';

switch ($op) {
    case 'add_school':
        $name = trim($_POST['name'] ?? '');
        $name = strtolower($name);
        $name = strtoupper($name);
        if ($name == '') exit('School name required');
        $stmt = $conn->prepare("INSERT INTO schools (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    case 'add_user':
        $employee_name = trim($_POST['employee_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $school_ids = $_POST['schools'] ?? [];

        if ($employee_name == '' || $username == '' || $password == '' || count($school_ids) == 0) {
            exit('All fields are required.');
        }

        // Check if username exists
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $checkStmt->bind_param("s", $username);
        $checkStmt->execute();
        $checkStmt->store_result();
        if ($checkStmt->num_rows > 0) {
            exit('Username already exists.');
        }
        $checkStmt->close();

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Save user
        $stmt = $conn->prepare("INSERT INTO users (employee_name, username, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $employee_name, $username, $hashedPassword);
        if (!$stmt->execute()) exit('Failed to add user.');

        // Save assigned schools
        $stmt2 = $conn->prepare("INSERT INTO user_school (user_id, school_id) VALUES (?, ?)");

        $user_id = $conn->insert_id;
        foreach ($school_ids as $school_id) {
            $sid = intval($school_id);
            $stmt2->bind_param("ii", $user_id, $sid);
            $stmt2->execute();
        }

        echo 'ok';
        break;

    case 'update_user':
        $user_id = intval($_POST['user_id'] ?? 0);
        $employee_name = trim($_POST['employee_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? ''); // optional for update
        $school_ids = $_POST['schools'] ?? [];

        if ($user_id == 0 || $employee_name == '' || $username == '' || count($school_ids) == 0) {
            exit('All fields except password are required.');
        }

        // Check if username belongs to another user
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $checkStmt->bind_param("si", $username, $user_id);
        $checkStmt->execute();
        $checkStmt->store_result();
        if ($checkStmt->num_rows > 0) {
            exit('Username already exists for another user.');
        }
        $checkStmt->close();

        if ($password != '') {
            // Update including password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET employee_name = ?, username = ?, password = ? WHERE id = ?");
            $stmt->bind_param("sssi", $employee_name, $username, $hashedPassword, $user_id);
        } else {
            // Update without changing password
            $stmt = $conn->prepare("UPDATE users SET employee_name = ?, username = ? WHERE id = ?");
            $stmt->bind_param("ssi", $employee_name, $username, $user_id);
        }

        if (!$stmt->execute()) exit('Failed to update user.');

        // Delete old school assignments
        $conn->query("DELETE FROM user_school WHERE user_id = $user_id");

        // Insert new school assignments
        $stmt2 = $conn->prepare("INSERT INTO user_school (user_id, school_id) VALUES (?, ?)");
        foreach ($school_ids as $school_id) {
            $sid = intval($school_id);
            $stmt2->bind_param("ii", $user_id, $sid);
            $stmt2->execute();
        }

        echo 'ok';
        break;

    case 'add_work_item':
        $school_id = intval($_POST['school_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $title = strtolower($title);
        $title = strtoupper($title);
        if ($school_id == 0 || $title == '') exit('Invalid input');
        $stmt = $conn->prepare("INSERT INTO work_items (school_id, title, start_date) VALUES (?, ?, CURDATE())");
        $stmt->bind_param("is", $school_id, $title);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    case 'add_subtask':
        $work_id = intval($_POST['work_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $title = strtolower($title);
        $title = strtoupper($title);
        if ($work_id == 0 || $title == '') exit('Invalid input');
        $stmt = $conn->prepare("INSERT INTO item_subtasks (work_item_id, title, is_done) VALUES (?, ?, 0)");
        $stmt->bind_param("is", $work_id, $title);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    case 'list_schools':
        $result = $conn->query("SELECT id, name FROM schools ORDER BY name ASC");
        $schools = [];
        while ($row = $result->fetch_assoc()) {
            $schools[] = $row;
        }
        echo json_encode($schools);
        break;

    case 'list_work_items':
        $school_id = intval($_POST['school_id'] ?? 0);
        $stmt = $conn->prepare("SELECT id, title FROM work_items WHERE school_id = ?");
        $stmt->bind_param("i", $school_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        echo json_encode($items);
        break;

    case 'list_all_work_items':
        $result = $conn->query("SELECT id, title FROM work_items ORDER BY id DESC");
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        echo json_encode($items);
        break;

    case 'list_all_subtasks':
        $result = $conn->query("SELECT id, title FROM item_subtasks ORDER BY id DESC");
        $subs = [];
        while ($row = $result->fetch_assoc()) {
            $subs[] = $row;
        }
        echo json_encode($subs);
        break;

    case 'list_subtasks_by_school':
        $sid = intval($_POST['school_id']);
        $sql = "SELECT st.id, st.title FROM item_subtasks st
                JOIN work_items w ON st.work_item_id = w.id
                WHERE w.school_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $sid);
        $stmt->execute();
        $res = $stmt->get_result();
        $arr = [];
        while ($r = $res->fetch_assoc()) $arr[] = $r;
        echo json_encode($arr);
        break;

    case 'update_school':
        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        $name = strtolower($name);
        $name = strtoupper($name);
        if ($name == '') exit('Name cannot be empty');
        $stmt = $conn->prepare("UPDATE schools SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    case 'update_work':
        $id = intval($_POST['id']);
        $title = trim($_POST['title']);
        $title = strtolower($title);
        $title = strtoupper($title);
        if ($title == '') exit('Title cannot be empty');
        $stmt = $conn->prepare("UPDATE work_items SET title = ? WHERE id = ?");
        $stmt->bind_param("si", $title, $id);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    case 'update_subtask':
        $id = intval($_POST['id']);
        $title = trim($_POST['title']);
        $title = strtolower($title);
        $title = strtoupper($title);
        if ($title == '') exit('Title cannot be empty');
        $stmt = $conn->prepare("UPDATE item_subtasks SET title = ? WHERE id = ?");
        $stmt->bind_param("si", $title, $id);
        echo $stmt->execute() ? 'ok' : 'error';
        break;

    default:
        echo "Invalid operation";
        break;
}
