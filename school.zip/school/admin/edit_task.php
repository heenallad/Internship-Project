<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}


include 'db.php';

// Fetch list of schools
$schools = $conn->query("SELECT id, name FROM schools");

// School filter
$schoolId = $_GET['school_id'] ?? '';

// Update is_done status if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['is_done_all'])) {
  $allIds = $_POST['is_done_all'];
  $checkedIds = isset($_POST['is_done']) ? array_keys($_POST['is_done']) : [];

  // Prepare two separate statements
  $stmtClearRemarks = $conn->prepare("UPDATE item_subtasks SET is_done = ?, remarks = NULL WHERE id = ?");
  $stmtPreserveRemarks = $conn->prepare("UPDATE item_subtasks SET is_done = ? WHERE id = ?");

  foreach ($allIds as $subtaskId) {
    $isDone = in_array($subtaskId, $checkedIds) ? 1 : 0;
    if ($isDone === 0) {
      $stmtClearRemarks->bind_param('ii', $isDone, $subtaskId);
      $stmtClearRemarks->execute();
    } else {
      $stmtPreserveRemarks->bind_param('ii', $isDone, $subtaskId);
      $stmtPreserveRemarks->execute();
    }
  }

  $stmtClearRemarks->close();
  $stmtPreserveRemarks->close();
}



// Fetch tasks
$sql = "
    SELECT 
        wi.id AS work_item_id, 
        wi.title AS work_title, 
        st.id AS subtask_id,
        st.title AS subtask_title,
        st.is_done,
        st.remarks
    FROM work_items wi
    LEFT JOIN item_subtasks st ON wi.id = st.work_item_id
";

if (!empty($schoolId)) {
  $sql .= " WHERE wi.school_id = " . intval($schoolId);
}

$sql .= " ORDER BY wi.id, st.id";

$result = $conn->query($sql);

// For display
$prevWorkId = null;
$srNo = 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Category-Based Report (Admin)</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- DataTables CSS -->
  <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      padding: 40px;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    .table-container {
      max-width: 95%;
      margin: auto;
    }

    label[for="school"] {
      font-weight: bold;
      font-size: 1.1em;
      margin-right: 10px;
      color: #333;
    }

    select#school {
      padding: 8px 12px;
      font-size: 1em;
      border: 2px solid rgb(15, 16, 15);
      border-radius: 6px;
      background-color: #f9f9f9;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
    }

    select#school:focus {
      outline: none;
      border-color: rgb(12, 13, 12);
      box-shadow: 0 0 8px rgba(46, 125, 50, 0.5);
    }
  </style>
</head>

<body>
  <div class="table-container">
    <a href="index.php" class="btn btn-outline-dark mb-3">← Back to Dashboard</a>
    <h2>📋 Edit Work Tasks</h2>

    <!-- School Filter with Action Button -->
    <form method="GET" class="d-flex align-items-center mb-4" style="gap: 10px;">
      <label for="school"><strong>Select School:</strong></label>
      <select name="school_id" id="school" class="form-select w-auto">
        <option value="">-- All Schools --</option>
        <?php
        // Reset pointer if needed
        $schools->data_seek(0);
        while ($school = $schools->fetch_assoc()): ?>
          <option value="<?= $school['id'] ?>" <?= ($schoolId == $school['id']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($school['name']) ?>
          </option>
        <?php endwhile; ?>
      </select>
      <button type="submit" class="btn btn-primary">🔍 View Tasks</button>
    </form>

    <!-- Task & Subtask Table -->
    <form method="POST">
      <!-- Save Button (Top) -->
      <div class="text-end mb-2">
        <button type="submit" class="btn btn-success">💾 Save Changes</button>
      </div>

      <table id="workTable" class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Sr No</th>
            <th>Work Title</th>
            <th>Subtask Title</th>
            <th>Done</th>
            <th>Remarks</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $srNo++ ?></td>
              <td>
                <?php
                if ($row['work_item_id'] !== $prevWorkId) {
                  echo htmlspecialchars($row['work_title']);
                  $prevWorkId = $row['work_item_id'];
                }
                ?>
              </td>
              <td><?= htmlspecialchars($row['subtask_title'] ?? '—') ?></td>
              <td>
                <?php if (!empty($row['subtask_title'])): ?>
                  <input
                    type="checkbox"
                    name="is_done[<?= $row['subtask_id'] ?>]"
                    value="1"
                    <?= $row['is_done'] ? 'checked' : '' ?> />
                <?php endif; ?>
                <input type="hidden" name="is_done_all[]" value="<?= $row['subtask_id'] ?>" />
              </td>
              <td><?= htmlspecialchars($row['remarks'] ?? '—') ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>

      <!-- Save Button (Bottom) -->
      <div class="text-end mt-3">
        <button type="submit" class="btn btn-success">💾 Save Changes</button>
      </div>
    </form>
  </div>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>

  <!-- <script>
    $(document).ready(function() {
      $('#workTable').DataTable({
        dom: 'Bfrtip',
        buttons: ['excel', 'pdf', 'print']
      });
    });
  </script> -->
  <script>
    $(document).ready(function() {
      $('#workTable').DataTable({
        pageLength: 10,
        lengthMenu: [10, 25, 50],
        language: {
          search: "🔍 Search:",
          lengthMenu: "Show _MENU_ entries",
          zeroRecords: "No matching records found",
          info: "Showing _START_ to _END_ of _TOTAL_ reports",
          infoEmpty: "No reports available",
          infoFiltered: "(filtered from _MAX_ total records)"
        }
      });
    });
  </script>
</body>

</html>