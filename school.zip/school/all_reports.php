
<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
// Check if user is an user
if ($_SESSION['role'] !== 'admin') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>School Work Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css" rel="stylesheet">

    <script>
        // Disable Right-Click
        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
        });

        // Disable DevTools Shortcut Keys
        document.addEventListener("keydown", function(e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) {
                e.preventDefault();
            }
        });

        // Optional: Detect if DevTools is open (basic)
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > 200) {
                document.body.innerHTML = "<h1>Inspect Disabled</h1>";
            }
        }, 1000);
    </script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        li {
            text-align: left;
        }

        .completed-row {
            background-color: #d4edda !important;
        }

        td.school-cell {
            vertical-align: bottom;
            font-weight: 600;
        }

        .logout-link {
            /* position: fixed; */
            top: 1em;
            left: 78em;
            background: red;
            color: white;
            padding: 0.5em 1.2em;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 0.4em;
            text-decoration: none;
            z-index: 999;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgb(249, 246, 246);
        }

        @media print {
            @page {
                size: landscape;
            }
        }

        /* Custom Styling for DataTables Pagination */
        .dataTables_paginate {
            text-align: center;
        }

        .dataTables_paginate .paginate_button {
            background: #f8f9fa;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 5px 10px;
            margin: 0 5px;
            font-weight: bold;
            color: #555;
            transition: background-color 0.3s, color 0.3s;
        }

        .dataTables_paginate .paginate_button:hover {
            background-color: #007bff;
            color: white;
        }

        .dataTables_paginate .paginate_button:active {
            background-color: #0056b3;
            color: white;
        }

        .dataTables_paginate .paginate_button.current {
            background-color: #007bff;
            color: white;
        }

        .export-btn {
            margin-right: 10px;
            margin-bottom: 20px;

        }
    </style>
</head>

<body>
    <div class="container my-5">
        <h2 class="text-center mb-4">School Work Dashboard</h2>
        <a href="index.php" class="btn btn-secondary mb-4">← Back to Dashboard</a>
        <!-- <a href="../logout.php" class="logout-link" aria-label="Logout from user panel">Logout</a> -->

        <div class="table-responsive mb-3">
            <table id="reportTable" class="table table-bordered table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>School</th>
                        <th>Title</th>
                        <th>Total</th>
                        <th>Completed</th>
                        <th>Pending</th>
                        <th>%</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody id="workTableBody"></tbody>
            </table>
        </div>
    </div>

    <!-- JS libraries -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

    <!-- DataTables Buttons JS -->
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.0/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/rowgroup/1.3.1/js/dataTables.rowGroup.min.js"></script>

    <script>
        $(function() {
            $.get('fetch_all_data.php', function(schools) {
                let html = '';

                schools.forEach(school => {
                    school.work_items.forEach(work_item => {
                        const pct = work_item.total ? ((work_item.completed / work_item.total) * 100).toFixed(1) : '0.0';

                        // Prepare the HTML for completed and pending tasks
                        const completedText = work_item.completed_titles.length > 0 ?
                            `<ul>${work_item.completed_titles.map(t => `<li>✅ ${t}</li>`).join('')}</ul>` :
                            'None';

                        const pendingText = work_item.pending_titles.length > 0 ?
                            `<ul>${work_item.pending_titles.map(t => `<li>⏳ ${t}</li>`).join('')}</ul>` :
                            'None';

                        html += `<tr>
              <td>${school.school_name}</td>
              <td>${work_item.title}</td>
              <td>${work_item.total}</td>
              <td>${completedText}</td>
              <td>${pendingText}</td>
              <td>${pct}%</td>
              <td>${work_item.start_date || ''}</td>
              <td>${work_item.end_date || ''}</td>
              <td>${work_item.remarks || ''}</td>
            </tr>`;
                    });
                });

                $('#workTableBody').html(html);

                // Initialize the DataTable with export buttons
                let dt = $('#reportTable').DataTable({
                    dom: 'Blfrtip', // Buttons on top, table below
                    buttons: [{
                            extend: 'excelHtml5',
                            className: 'btn btn-success export-btn', // Add custom class for Excel button
                            text: 'Export Excel',
                            exportOptions: {
                                format: {
                                    body: function(data, row, column, node) {
                                        if (typeof data === 'string') {
                                            data = data.replace(/<\/?ol[^>]*>/g, '');
                                            data = data.replace(/<li>/g, '\n- ').replace(/<\/li>/g, '');
                                            data = data.replace(/<\/?[^>]+(>|$)/g, '');
                                            data = data.trim();
                                        }
                                        return data;
                                    }
                                }
                            }
                        },
                        {
                            extend: 'pdfHtml5',
                            className: 'btn btn-danger export-btn',
                            text: 'Export PDF',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            // download: 'open',
                            exportOptions: {
                                format: {
                                    body: function(data) {
                                        return data
                                            .replace(/✅/g, ' ')
                                            .replace(/⏳/g, ' ')
                                            .replace(/<li>/g, '\n• ')
                                            .replace(/<\/li>/g, '')
                                            .replace(/<\/?[^>]+(>|$)/g, '')
                                            .trim();
                                    }
                                }
                            },
                            customize: function(doc) {
                                // // Base64 icons
                                // const doneImg = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAMFJREFUeNpi/P//PwMlgImBQjDwH6AYQ7wH3P4cX4bYGZABxEIwDIzwZBDGjoBRWqgcO+BTJAEUGgBgB6D0EK2uMdIK7wF8D0HZIGqWIBm1DdHkAcwQ0PQKgBvgBhaY2R4AFWg9hUIHWyYQFi8DuPwoAUoLYFYIxDuAAAMAt7N5mH7OiEAAAAASUVORK5CYII=';
                                // const pendingImg = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAOVJREFUeNpi/P//PwMlgImBQjDwH6AYQ7wH3P4cX4bYGZABxEIwDIzwZBDGjoBRWqgcO+BTJAEUGgBgB6D0EK2uMdIK7wF8D0HZIGqWIBm1DdHkAcwQ0PQKgBvgBhaY2R4AFWg9hUIHWyYQFi8DuPwoAUoLYFYIxDuAAAMAxDlN3UZYwQAAAABJRU5ErkJggg==';


                                // Set column widths
                                doc.content[1].table.widths = ['10%', '10%', '4%', '24%', '20%', '5%', '7%', '7%', '15%'];

                                // Justify alignment and font size
                                doc.defaultStyle.fontSize = 9;
                                doc.styles.tableHeader.fontSize = 10;
                                doc.styles.tableBodyEven.alignment = 'justify';
                                doc.styles.tableBodyOdd.alignment = 'justify';

                                // Compact table layout
                                doc.content[1].layout = {
                                    hLineWidth: () => 0.5,
                                    vLineWidth: () => 0.5,
                                    hLineColor: () => '#aaa',
                                    vLineColor: () => '#aaa',
                                    paddingLeft: () => 4,
                                    paddingRight: () => 4,
                                    paddingTop: () => 4,
                                    paddingBottom: () => 4
                                };

                                // Replace text placeholders with images

                            }
                        }
                    ],

                    order: [
                        [0, 'asc']
                    ], // Default order by school name (column 0)
                    rowGroup: {
                        dataSrc: 0
                    }, // Group rows by school name
                    pageLength: 10, // Number of rows per page
                    pagingType: 'full_numbers', // Display full pagination with next/previous and page numbers
                    language: {
                        paginate: {
                            previous: '<', // Previous button
                            next: '>', // Next button
                            first: '<<', // First button
                            last: '>>' // Last button
                        },
                        lengthMenu: 'Show _MENU_ entries per page',
                        info: 'Showing page _PAGE_ of _PAGES_',
                        infoEmpty: 'No records available'
                    }
                });
            });
        });
    </script>
</body>

</html>