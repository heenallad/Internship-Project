-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 11, 2025 at 08:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_subtasks`
--

CREATE TABLE `item_subtasks` (
  `id` int(11) NOT NULL,
  `work_item_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `is_done` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_subtasks`
--

INSERT INTO `item_subtasks` (`id`, `work_item_id`, `title`, `is_done`, `remarks`) VALUES
(15, 5, 'before order check if school has space or not', 0, ''),
(16, 5, 'prepare ppc platform before delivery', 0, ''),
(17, 5, 'deliver items directly to school', 0, ''),
(18, 5, 'ask install team to finish installation', 0, ''),
(19, 5, 'apply rubber mat after installation', 0, ''),
(20, 5, 'take photo and certificate', 0, ''),
(21, 5, 'prepare and submit invoice', 0, ''),
(22, 6, 'before order check if school has space or not', 0, ''),
(23, 6, 'do ground leveling/ tiles/ kota/ paver block removal', 0, ''),
(24, 6, 'do pcc as per guided design', 0, ''),
(25, 6, 'do smoothening of first surface after pcc is done', 0, ''),
(26, 6, 'take photo', 0, ''),
(27, 7, 'after smoothening of pcc is done, install rubber mat with weather proof rubber adhesive', 1, ''),
(28, 7, 'take photo and certificate', 1, ''),
(29, 7, 'prepare and submit invoice', 1, ''),
(30, 8, 'as we received material, discuss with headmaster take confirmation to deliver item and do delivery', 0, ''),
(31, 8, 'take photo', 0, ''),
(32, 9, 'as we received material, discuss with headmaster take confirmation to deliver item and do delivery', 0, ''),
(33, 9, 'take photo', 0, ''),
(34, 10, 'EXPLAIN HEAD MASTER ABOUT SINAGE BOARD AND PREPARE SCHOOL LAYOUT MENTIONING WHICH STANDARD IS WHERE', 0, ''),
(35, 10, 'AS WE RECEIVED MATERIAL, DISCUSS WITH HEADMASTER TAKE CONFIRMATION TO DELIVER ITEM AND DO DELIVERY', 0, ''),
(36, 10, 'DO INSTALLATION AS PER LAYOUT DISCUSSED EARLIER', 0, ''),
(37, 10, 'TAKE PHOTO AND CERTIFICATE', 0, ''),
(38, 10, 'PREPARE AND SUBMIT INVOICE', 0, ''),
(39, 11, 'AS WE RECEIVED MATERIAL, DISCUSS WITH HEADMASTER TAKE CONFIRMATION TO DELIVER ITEM AND DO DELIVERY', 1, ''),
(40, 11, 'TAKE PHOTO AND CERTIFICATE', 1, 'Cleared'),
(41, 11, 'PREPARE AND SUBMIT INVOICE', 1, 'Done'),
(42, 12, 'EXPLAIN HEAD MASTER ABOUT SMART PANNEL AND PREPARE SCHOOL LAYOUT MENTIONING WHERE TO INSTALL', 1, 'Explained'),
(43, 12, 'AS WE RECEIVED MATERIAL, DISCUSS WITH HEADMASTER TAKE CONFIRMATION TO DELIVER ITEM AND DO DELIVERY', 1, 'Discussed'),
(44, 12, 'ASK ELECTRICAL TEAM TO MAKE POWER SORCE FOR THE ITEM', 1, 'Asked & Noted'),
(45, 12, 'DO INSTALLATION AS PER LAYOUT DISCUSSED EARLIER', 0, ''),
(46, 12, 'TAKE PHOTO AND CERTIFICATE', 0, ''),
(47, 12, 'PREPARE AND SUBMIT INVOICE', 0, ''),
(48, 13, 'EXPLAIN HEAD MASTER ABOUT RAIN WATER HARVESTING SYSTEM AND DISCUSS ABOUT WHERE TO INSTALL WATER TANK, 1 HP MOTOR, FILTER', 0, ''),
(49, 13, 'ASK PURCHASE TEAM TO TALK TO INSTALL TEAM TO START PCC WORK FOR WATER TANK BASE THAN ARRANGE INSTALLATION FOR PIPELINES AND FILTER SETUP', 0, ''),
(50, 13, 'FINISH INSTALLATION FOR ALL SUB PART OF RAIN WATER HARVESTING SYSTEM', 0, ''),
(51, 13, 'AFTER ALL ITEMS ARE INSTALLED CHECK IF THE WHOLE SYSTEM IS WORKING OR NOT. IF NOT WORKING PROPERLY ASK INSTALL TEAM TO MAKE CORRECTIONS', 0, ''),
(52, 13, 'TAKE PHOTO AND CERTIFICATE', 0, ''),
(53, 13, 'PREPARE AND SUBMIT INVOICE', 1, ''),
(54, 14, 'DISCUSS WITH HEAD MASTER ABOUT GRAPHIC CONTENT OF WALLPAPER AND CREATE A LAYOUT OF SCHOOL MENTIONING WHICH STANDARD CLASS IS WHERE AND TAKE ALL CONFIRMATION FROM HEAD MASTER BEFORE STARTING ANY GRAPHICS ADAPTATION WORK', 0, ''),
(55, 14, 'TAKE WALL MEASUREMENTS', 0, ''),
(56, 14, 'START DOING PUTTY 1 COAT SIDE BY SIDE WITH WALL MEASUREMENT', 0, ''),
(57, 14, 'DO GASAI AND APPLY 2ND COAT OF WALL PUTTY', 0, ''),
(58, 14, 'DO GASAI AND APPLY PRIMAR', 0, ''),
(59, 14, 'AFTER 2 COAT PUTTY PRIMAR DONE START PASTING WALLPAPER', 0, ''),
(60, 14, 'VERIFY PUTTY AND WALLPAPER MEASUREMENTS', 0, ''),
(61, 14, 'TAKE PHOTO AND CERTIFICATE', 0, ''),
(62, 14, 'PREPARE AND SUBMIT INVOICE', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `name`) VALUES
(1, 'ABCDE'),
(2, 'DEF'),
(3, 'xyz'),
(4, 'IJK');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `employee_name`, `username`, `password`, `role`, `created_at`) VALUES
(1, '', 'admin', '$2y$10$odn8P/t8Utfw8Ldse4AsJeET7/72hEQFAmOYDSe2EzTYceHai7doG', 'admin', '2025-07-04 00:33:28'),
(2, '', 'user', '$2y$10$Kfjr1rjxC3r1Wo5nzUIIp.vFhxDBEHmmezJ8aGEIuQxqCksvTtWsm', 'user', '2025-07-04 00:33:58'),
(5, 'ABCD', 'user1', '$2y$10$mUOsTka1xPvSlvf1AeoY2.kVFCIa7iJGhWMWUOvD..hl/dITBlbmy', 'user', '2025-07-05 06:22:35'),
(6, 'D', 'user2', '$2y$10$opVqNdtkMdnAXoAKWKUbaujLmDpaDNPC3g2SmXNd8TzWS1RtVJ6xy', 'user', '2025-07-05 06:22:50'),
(7, 'POQR', 'user3', '$2y$10$prFYh0g7TOlKjJmGdG0WN.PXO/CtdCPOnZ4KrCfEWTb6LMWRTGJp.', 'user', '2025-07-08 10:57:42');

-- --------------------------------------------------------

--
-- Table structure for table `user_school`
--

CREATE TABLE `user_school` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_school`
--

INSERT INTO `user_school` (`id`, `user_id`, `school_id`) VALUES
(5, 6, 2),
(6, 5, 1),
(7, 5, 2),
(8, 7, 4),
(9, 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `work_items`
--

CREATE TABLE `work_items` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT 0,
  `completed` int(11) NOT NULL DEFAULT 0,
  `pending` int(11) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_items`
--

INSERT INTO `work_items` (`id`, `school_id`, `title`, `total`, `completed`, `pending`, `start_date`, `end_date`) VALUES
(5, 1, 'Multi Play Station', 7, 3, 4, '2025-07-04', NULL),
(6, 1, 'PCC for Multi Play Station', 5, 3, 2, '2025-07-04', NULL),
(7, 1, 'Outdoor Rubber Mat for Multi Play Station', 3, 3, 0, '2025-07-04', '2025-07-16'),
(8, 2, 'Microphone', 2, 2, 0, '2025-07-04', '2025-07-04'),
(9, 2, 'Ahuja Speaker', 2, 2, 0, '2025-07-04', '2025-07-05'),
(10, 3, 'SINAGE BOARD', 0, 0, 0, '2025-07-07', NULL),
(11, 1, 'PORTABLE SOUND SYSTEM', 3, 3, 0, '2025-07-07', '2025-07-10'),
(12, 2, 'smart panel', 0, 3, 3, '2025-07-07', NULL),
(13, 3, 'RAIN WATER HARVESTING SYSTEM', 0, 6, 0, '2025-07-07', '2025-07-10'),
(14, 4, 'WALL PAPER (3D EDUCATIONAL CHART)', 0, 0, 0, '2025-07-08', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_subtasks`
--
ALTER TABLE `item_subtasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `work_item_id` (`work_item_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_school`
--
ALTER TABLE `user_school`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `work_items`
--
ALTER TABLE `work_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_subtasks`
--
ALTER TABLE `item_subtasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_school`
--
ALTER TABLE `user_school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `work_items`
--
ALTER TABLE `work_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `item_subtasks`
--
ALTER TABLE `item_subtasks`
  ADD CONSTRAINT `item_subtasks_ibfk_1` FOREIGN KEY (`work_item_id`) REFERENCES `work_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_school`
--
ALTER TABLE `user_school`
  ADD CONSTRAINT `user_school_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_school_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `work_items`
--
ALTER TABLE `work_items`
  ADD CONSTRAINT `work_items_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
