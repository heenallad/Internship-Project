<?php
session_start();
include 'db.php';
date_default_timezone_set('Asia/Kolkata');

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) exit('Unauthorized');

$op = $_POST['op'] ?? '';

if ($op === 'list_schools') {
    $stmt = $conn->prepare("
        SELECT s.id, s.name 
        FROM schools s
        JOIN user_school us ON us.school_id = s.id
        WHERE us.user_id = ?
        ORDER BY s.name
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    echo json_encode($res->fetch_all(MYSQLI_ASSOC));
    exit;
}

if ($op === 'fetch_all') {
    $school_id = isset($_POST['school_id']) ? intval($_POST['school_id']) : 0;

    $sql = "SELECT wi.*, s.name AS school_name
            FROM work_items wi
            JOIN schools s ON wi.school_id = s.id
            JOIN user_school us ON us.school_id = s.id
            WHERE us.user_id = ?";

    if ($school_id > 0) {
        $sql .= " AND s.id = ?";
    }

    $sql .= " ORDER BY wi.id DESC";

    $stmt = $conn->prepare($sql);
    if ($school_id > 0) {
        $stmt->bind_param("ii", $user_id, $school_id);
    } else {
        $stmt->bind_param("i", $user_id);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $workItems = [];

    while ($r = $result->fetch_assoc()) {
        $wid = (int)$r['id'];

        $resC = $conn->query("SELECT title FROM item_subtasks WHERE work_item_id=$wid AND is_done=1");
        $r['completed_titles'] = array_column($resC->fetch_all(MYSQLI_ASSOC), 'title');

        $resR = $conn->query("SELECT remarks FROM item_subtasks WHERE work_item_id=$wid AND remarks IS NOT NULL AND TRIM(remarks) != ''");
        $r['remarks'] = array_column($resR->fetch_all(MYSQLI_ASSOC), 'remarks');

        $resP = $conn->query("SELECT title FROM item_subtasks WHERE work_item_id=$wid AND is_done=0");
        $r['pending_titles'] = array_column($resP->fetch_all(MYSQLI_ASSOC), 'title');

        $workItems[] = $r;
    }

    echo json_encode($workItems);
    exit;
}

if ($op === 'list_work_items') {
    $sid = (int)$_POST['school_id'];

    $check = $conn->prepare("SELECT 1 FROM user_school WHERE user_id = ? AND school_id = ?");
    $check->bind_param("ii", $user_id, $sid);
    $check->execute();
    $check->store_result();
    if ($check->num_rows === 0) exit(json_encode([]));

    $stmt = $conn->prepare("SELECT id, title FROM work_items WHERE school_id = ? ORDER BY id DESC");
    $stmt->bind_param("i", $sid);
    $stmt->execute();
    $res = $stmt->get_result();
    echo json_encode($res->fetch_all(MYSQLI_ASSOC));
    exit;
}

if ($op === 'update_subtasks') {
    $updates = json_decode($_POST['updates'], true);
    $workIds = [];

    foreach ($updates as $item) {
        $id = (int)$item['id'];
        $is_done = (int)$item['is_done'];
        $remarks = trim($item['remarks']);

        // Update each subtask
        $stmt = $conn->prepare("UPDATE item_subtasks SET is_done = ?, remarks = ? WHERE id = ?");
        $stmt->bind_param("isi", $is_done, $remarks, $id);
        if (!$stmt->execute()) {
            echo json_encode(['status' => 'error', 'message' => $stmt->error]);
            exit;
        }
        $stmt->close();

        // Get the related work_item_id
        $stmt = $conn->prepare("SELECT work_item_id FROM item_subtasks WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($workId);
        if ($stmt->fetch()) {
            $workIds[] = $workId;
        }
        $stmt->close();
    }

    // Remove duplicates
    $workIds = array_unique($workIds);

    foreach ($workIds as $wid) {
        // Get total subtasks
        $stmt = $conn->prepare("SELECT COUNT(*) FROM item_subtasks WHERE work_item_id = ?");
        $stmt->bind_param("i", $wid);
        $stmt->execute();
        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();

        // Get completed subtasks
        $stmt = $conn->prepare("SELECT COUNT(*) FROM item_subtasks WHERE work_item_id = ? AND is_done = 1");
        $stmt->bind_param("i", $wid);
        $stmt->execute();
        $stmt->bind_result($completed);
        $stmt->fetch();
        $stmt->close();

        $pending = $total - $completed;

        // Update work_items table — now includes total
        if ($completed === $total && $total > 0) {
            $stmt = $conn->prepare("UPDATE work_items SET total = ?, completed = ?, pending = ?, end_date = NOW() WHERE id = ?");
        } else {
            $stmt = $conn->prepare("UPDATE work_items SET total = ?, completed = ?, pending = ?, end_date = NULL WHERE id = ?");
        }

        $stmt->bind_param("iiii", $total, $completed, $pending, $wid);
        if (!$stmt->execute()) {
            echo json_encode(['status' => 'error', 'message' => $stmt->error]);
            exit;
        }
        $stmt->close();
    }

    echo json_encode(['status' => 'success']);
    exit;
}

if ($op === 'add_school') {
    $name = $conn->real_escape_string(trim($_POST['name']));
    if (!$name) exit('School name required');
    $check = $conn->query("SELECT id FROM schools WHERE name='$name'");
    if ($check->num_rows > 0) exit('School already exists.');
    $conn->query("INSERT INTO schools (name) VALUES ('$name')");
    exit('ok');
}

if ($op === 'add_work_item') {
    $sid = (int)$_POST['school_id'];
    $title = $conn->real_escape_string(trim($_POST['title']));

    $check = $conn->prepare("SELECT 1 FROM user_school WHERE user_id = ? AND school_id = ?");
    $check->bind_param("ii", $user_id, $sid);
    $check->execute();
    $check->store_result();
    if ($check->num_rows === 0) exit('Unauthorized');

    if (!$title) exit('Work title required');

    $check = $conn->query("SELECT id FROM work_items WHERE school_id=$sid AND title='$title'");
    if ($check->num_rows > 0) exit('Work item already exists.');

    $conn->query("INSERT INTO work_items (school_id, title, start_date) VALUES ($sid, '$title', CURDATE())");
    $wid = $conn->insert_id;

    for ($i = 1; $i <= 5; $i++) {
        $conn->query("INSERT INTO item_subtasks (work_item_id, title) VALUES ($wid, 'Subtask $i')");
    }

    $conn->query("UPDATE work_items SET total=5, pending=5, completed=0 WHERE id=$wid");
    exit('ok');
}

if ($op === 'get_subtasks') {
    $wid = (int)$_POST['work_id'];

    $stmt = $conn->prepare("
        SELECT ist.id, ist.title, ist.is_done, ist.remarks
        FROM item_subtasks ist
        JOIN work_items wi ON wi.id = ist.work_item_id
        JOIN user_school us ON us.school_id = wi.school_id
        WHERE ist.work_item_id = ? AND us.user_id = ?
    ");
    $stmt->bind_param("ii", $wid, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $subtasks = [];
    while ($row = $result->fetch_assoc()) {
        $subtasks[] = $row;
    }

    echo json_encode($subtasks);
    exit;
}

