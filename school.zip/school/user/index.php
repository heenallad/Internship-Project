<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
  header('Location: ../index.php');
  exit;
}

// Check if user is an user
if ($_SESSION['role'] !== 'user') {
  header('Location: ../unauthorized.php'); // or show error
  exit;
}
?>

<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>School Work Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css" rel="stylesheet">
  <!-- <link rel="stylesheet" href="../bootstrap-5.3.7-dist/css/bootstrap.min.css"> -->
  <style>
    * {
      padding: 0;
      margin: 0;
    }

    body {
      background-color: #f8f9fa;
    }

    .completed-row {
      background-color: #d4edda !important;
    }

    .export-btn {
      margin-right: 10px;
      margin-bottom: 20px;
      border-radius: 12px;
      padding: 10px;
    }

    .btn-success {
      background-color: green;
      color: white;
      border-radius: 12px;
      padding: 10px;
    }

    .btn-danger {
      background-color: red;
      color: white;
    }
  </style>

  <script>
    // Disable Right-Click
    document.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    });

    // Disable DevTools Shortcut Keys
    document.addEventListener("keydown", function(e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
      }
    });

    // Optional: Detect if DevTools is open (basic)
    setInterval(function() {
      if (window.outerHeight - window.innerHeight > 200) {
        document.body.innerHTML = "<h1>Inspect Disabled</h1>";
      }
    }, 1000);
  </script>
</head>

<body class="bg-gray-100">
  <div class="container mx-auto my-5">
    <h2 class="text-center text-2xl font-bold mb-4">School Work Dashboard</h2>

    <div class="mb-5">
      <a href="../logout.php" class="top-4 right-4 bg-red-500 text-white py-2 px-4 rounded shadow">Logout</a>
    </div>
    
    <!-- Subtasks + Remarks -->
    <div class="bg-white shadow-md rounded-lg mb-5">
      <div class="bg-blue-500 text-white p-4 rounded-t-lg">Subtasks</div>
      <div class="p-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
          <select id="schoolSelect" class="border border-gray-300 rounded px-3 py-2 w-full">
            <option value="">Select School</option>
          </select>
          <select id="workSelect" class="border border-gray-300 rounded px-3 py-2 w-full">
            <option value="">Select Work Item</option>
          </select>
        </div>

        <ul id="subtaskList" class="border border-gray-300 rounded px-3 py-2 w-full">
          <li class="list-group-item text-muted">Select school & work to view subtasks</li>
        </ul>
        <br>
        <div class="flex justify-end mb-2">
          <button id="submitSubtasksBtn" class="btn btn-sm btn-success">Submit</button>
        </div>
      </div>
    </div>
    <a href="view_report.php" class="fixed down-4 left-11 bg-blue-400 text-white py-2 px-4 rounded shadow">View Report</a>
</body>


<!-- JS libraries -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.0/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="../bootstrap-5.3.7-dist/js/bootstrap.bundle.min.js"></script>

<script>
  function loadSchools() {
    $.post('process.php', {
      op: 'list_schools'
    }, function(data) {
      const schools = JSON.parse(data);
      const options = schools.map(s => `<option value="${s.id}">${s.name}</option>`);
      $('#schoolSelect').html(`<option value="">Select School</option>` + options.join(''));
    });
  }

  function loadWorkItems(schoolId) {
    $.post('process.php', {
      op: 'list_work_items',
      school_id: schoolId
    }, function(data) {
      const workItems = JSON.parse(data);
      const options = workItems.map(w => `<option value="${w.id}">${w.title}</option>`);
      $('#workSelect').html(`<option value="">Select Work Item</option>` + options.join(''));
    });
  }

  function loadSubtasks(workId) {
    $.post('process.php', {
      op: 'get_subtasks',
      work_id: workId
    }, function(data) {
      const subtasks = JSON.parse(data);
      if (subtasks.length === 0) {
        $('#subtaskList').html('<li class="text-gray-500">No subtasks found.</li>');
        return;
      }

      const html = subtasks.map(s => {
        const isChecked = s.is_done == 1 ? 'checked' : '';
        const isDisabled = s.is_done == 1 ? 'disabled' : '';
        const textareaDisabled = s.is_done == 1 ? 'disabled' : '';
        const safeRemarks = s.remarks ? s.remarks.replace(/</g, "&lt;").replace(/>/g, "&gt;") : '';

        return `
        <li class="bg-gray-100 border border-gray-300 rounded p-3 mb-2">
          <div class="flex justify-between items-center">
            <span class="font-medium">${s.title}</span>
            <input type="checkbox" class="subtask-checkbox h-4 w-4 text-green-600" data-id="${s.id}" ${isChecked} ${isDisabled}>
          </div>
          <div class="mt-2">
            <textarea class="subtask-remarks w-full border rounded p-2 text-sm" data-id="${s.id}" rows="2" placeholder="Add details or notes..." ${textareaDisabled}>${safeRemarks}</textarea>
          </div>
        </li>
      `;
      }).join('');

      $('#subtaskList').html(html);
    });
  }

  $('#submitSubtasksBtn').on('click', function() {
    const updates = [];

    $('#subtaskList li').each(function() {
      const checkbox = $(this).find('.subtask-checkbox');
      const remarksBox = $(this).find('.subtask-remarks');

      if (checkbox.length && remarksBox.length) {
        const id = checkbox.data('id');
        const isDone = checkbox.is(':checked') ? 1 : 0;
        const remarks = remarksBox.val();

        updates.push({
          id,
          is_done: isDone,
          remarks
        });
      }
    });

    if (updates.length === 0) {
      alert('No changes to update.');
      return;
    }

    $.post('process.php', {
      op: 'update_subtasks',
      updates: JSON.stringify(updates)
    }, function(response) {
      const result = JSON.parse(response);
      if (result.status === 'success') {
        alert('Subtasks updated successfully!');
        location.reload();
        const selectedWork = $('#workSelect').val();
        if (selectedWork) loadSubtasks(selectedWork); // Reload subtasks only
      } else {
        alert('Update failed.');
      }
    });
  });

  $(function() {
    loadSchools();

    $('#schoolSelect').change(function() {
      const sid = $(this).val();
      $('#workSelect').html('<option value="">Select Work Item</option>');
      $('#subtaskList').html('<li class="text-gray-500">Please select a work item to view subtasks.</li>');
      if (sid) loadWorkItems(sid);
    });

    $('#workSelect').change(function() {
      const wid = $(this).val();
      if (wid) {
        loadSubtasks(wid);
      } else {
        $('#subtaskList').html('<li class="text-gray-500">Please select a work item to view subtasks.</li>');
      }
    });
  });
</script>
</body>

</html>