<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");


if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

// Check if user is an user
if ($_SESSION['role'] !== 'user') {
    header('Location: ../unauthorized.php'); // or show error
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Work Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css" rel="stylesheet">

    <style>
        * {
            padding: 0;
            margin: 0;
        }

        body {
            background-color: #f8f9fa;
        }

        .completed-row {
            background-color: #d4edda !important;
        }

        .export-btn {
            margin-right: 10px;
            margin-bottom: 20px;
            border-radius: 12px;
            padding: 10px;
        }

        .btn-success {
            background-color: green;
            color: white;
            border-radius: 12px;
            padding: 10px;
        }

        .btn-danger {
            background-color: red;
            color: white;
        }
    </style>

    <script>
        // Disable Right-Click
        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
        });

        // Disable DevTools Shortcut Keys
        document.addEventListener("keydown", function(e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) {
                e.preventDefault();
            }
        });

        // Optional: Detect if DevTools is open (basic)
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > 200) {
                document.body.innerHTML = "<h1>Inspect Disabled</h1>";
            }
        }, 1000);
    </script>
</head>

<body>

    <div class="container mx-auto my-5">
        <div class="mb-5">
            <a href="index.php" class="bg-gray-500 text-white py-2 px-6 rounded shadow">← Back to Dashboard</a>
        </div>

        <div class="bg-white shadow-md rounded-lg mb-5">
            <div class="bg-blue-400 text-white p-4 rounded-t-lg">Seclect School</div>
            <div class="p-4">
                <div class="md:grid-cols-2 gap-4 mb-3">
                    <select id="schoolSelect" class="border border-gray-300 rounded px-3 py-2 w-full">
                        <option value="">Select School</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="overflow-x-auto mb-3">
            <table id="reportTable" class="min-w-full bg-white border border-gray-300 text-center">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="border border-gray-300 px-4 py-2">School</th>
                        <th class="border border-gray-300 px-4 py-2">Title</th>
                        <th class="border border-gray-300 px-4 py-2">Total</th>
                        <th class="border border-gray-300 px-4 py-2">Completed</th>
                        <th class="border border-gray-300 px-4 py-2">Pending</th>
                        <th class="border border-gray-300 px-4 py-2">%</th>
                        <th class="border border-gray-300 px-4 py-2">Start</th>
                        <th class="border border-gray-300 px-4 py-2">End</th>
                        <th class="border border-gray-300 px-4 py-2">Remarks</th>
                    </tr>
                </thead>
                <tbody id="workTableBody">
                    <!-- Table rows will be populated here -->
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- JS libraries -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.0/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/rowgroup/1.3.1/js/dataTables.rowGroup.min.js"></script>
    <script src="../bootstrap-5.3.7-dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            loadSchools();

            $('#schoolSelect').on('change', function() {
                const schoolId = $(this).val();
                console.log('Selected School ID:', schoolId); // Debug log

                if (schoolId) {
                    loadMainTable(schoolId);
                } else {
                    // if ($.fn.DataTable.isDataTable('#reportTable')) {
                    //     dt.destroy();
                    // }
                    $('#workTableBody').html('<tr><td colspan="9" class="text-center">Please select a school to view data.</td></tr>');
                }
            });
        });

        let dt;

        function loadSchools() {
            $.post('process.php', {
                op: 'list_schools'
            }, function(data) {
                const schools = JSON.parse(data);
                const options = schools.map(s => `<option value="${s.id}">${s.name}</option>`);
                $('#schoolSelect').html('<option value="">Select School</option>' + options.join(''));
            });
        }

        function loadMainTable(schoolId) {
            $.post('process.php', {
                op: 'fetch_all',
                school_id: schoolId
            }, function(data) {
                const rows = JSON.parse(data);
                let html = '';

                rows.forEach(r => {
                    const pct = r.total > 0 ? (r.completed / r.total * 100).toFixed(1) : '0.0';
                    const rowClass = (r.total > 0 && r.completed === r.total) ? 'completed-row' : '';
                    const completedText = `<ol style="margin-bottom: 0; padding-left: 1rem; text-align: left;">${r.completed_titles.map(t => `<li>✅ ${t}</li>`).join('')}</ol>`;
                    const pendingText = `<ol style="margin-bottom: 0; padding-left: 1rem; text-align: left;">${r.pending_titles.map(t => `<li>⏳ ${t}</li>`).join('')}</ol>`;
                    const remarksText = r.remarks?.length ?
                        `<ol style="margin-bottom: 0; padding-left: 1rem; text-align: left;">${r.remarks.map(t => `<li>${t}</li>`).join('')}</ol>` :
                        '';

                    html += `<tr class="${rowClass}">
                <td class="border border-gray-300 px-4 py-2">${r.school_name}</td>
                <td class="border border-gray-300 px-4 py-2">${r.title}</td>
                <td class="border border-gray-300 px-4 py-2">${r.total}</td>
                <td class="border border-gray-300 px-4 py-2">${completedText}</td>
                <td class="border border-gray-300 px-4 py-2">${pendingText}</td>
                <td class="border border-gray-300 px-4 py-2">${pct}%</td>
                <td class="border border-gray-300 px-4 py-2">${r.start_date || ''}</td>
                <td class="border border-gray-300 px-4 py-2">${r.end_date || ''}</td>
                <td class="border border-gray-300 px-4 py-2">${remarksText}</td>
            </tr>`;
                });

                if (dt) {
                    dt.destroy();
                }

                $('#workTableBody').html(html);

                dt = $('#reportTable').DataTable({
                    dom: 'Blfrtip',
                    buttons: [{
                            extend: 'excelHtml5',
                            className: 'btn btn-success export-btn',
                            text: 'Export Excel',
                            exportOptions: {
                                format: {
                                    body: function(data) {
                                        return data.replace(/<\/?[^>]+(>|$)/g, '').trim();
                                    }
                                }
                            }
                        },
                        {
                            extend: 'pdfHtml5',
                            className: 'btn btn-danger export-btn',
                            text: 'Export PDF',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            exportOptions: {
                                format: {
                                    body: function(data) {
                                        return data
                                            .replace(/✅/g, ' ')
                                            .replace(/⏳/g, ' ')
                                            .replace(/<li>/g, '\n• ')
                                            .replace(/<\/li>/g, '')
                                            .replace(/<\/?[^>]+(>|$)/g, '')
                                            .trim();
                                    }
                                }
                            },
                            customize: function(doc) {
                                doc.content[1].table.widths = ['10%', '10%', '4%', '24%', '20%', '5%', '7%', '7%', '15%'];
                                doc.defaultStyle.fontSize = 9;
                                doc.styles.tableHeader.fontSize = 10;
                                doc.styles.tableBodyEven.alignment = 'justify';
                                doc.styles.tableBodyOdd.alignment = 'justify';
                                doc.content[1].layout = {
                                    hLineWidth: () => 0.5,
                                    vLineWidth: () => 0.5,
                                    hLineColor: () => '#aaa',
                                    vLineColor: () => '#aaa',
                                    paddingLeft: () => 4,
                                    paddingRight: () => 4,
                                    paddingTop: () => 4,
                                    paddingBottom: () => 4
                                };
                            }
                        }
                    ],
                    pageLength: 10,
                    lengthMenu: [10, 20, 30],
                    pagingType: "full_numbers",
                    order: [
                        [0, 'asc']
                    ],
                    rowGroup: {
                        dataSrc: 0
                    },
                    language: {
                        paginate: {
                            previous: '<',
                            next: '>',
                            first: '<<',
                            last: '>>'
                        }
                    }
                });
            });
        }
    </script>
</body>

</html>