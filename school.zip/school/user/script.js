function loadTable() {
  $.post('process.php', { op: 'fetch' }, function(data) {
    let html = '';
    let rows = JSON.parse(data);
    rows.forEach(row => {
      let pct = row.total > 0 ? ((row.completed / row.total) * 100).toFixed(1) : '0.0';
      html += `<tr>
        <td contenteditable data-field="school" data-id="${row.id}">${row.school}</td>
        <td contenteditable data-field="description" data-id="${row.id}">${row.description}</td>
        <td contenteditable data-field="total" data-id="${row.id}">${row.total}</td>
        <td contenteditable data-field="completed" data-id="${row.id}">${row.completed}</td>
        <td contenteditable data-field="pending" data-id="${row.id}">${row.pending}</td>
        <td>${pct}%</td>
        <td contenteditable data-field="start_date" data-id="${row.id}">${row.start_date}</td>
        <td contenteditable data-field="end_date" data-id="${row.id}">${row.end_date}</td>
        <td contenteditable data-field="remarks" data-id="${row.id}">${row.remarks}</td>
        <td><button class="btn btn-danger btn-sm deleteBtn" data-id="${row.id}">Delete</button></td>
      </tr>`;
    });
    $('#workTableBody').html(html);
  });
}

// Handle form submission
$('#addForm').on('submit', function(e) {
  e.preventDefault();
  const formData = $(this).serialize() + '&op=create';

  $.post('process.php', formData, function(res) {
    if (res.trim() === 'ok') {
      $('#addForm')[0].reset();
      loadTable();
    } else {
      alert("Insert failed: " + res);
    }
  });
});


$(document).ready(function() {
  loadTable();

  // Inline editing
  $(document).on('blur', 'td[contenteditable]', function() {
    let id = $(this).data('id');
    let field = $(this).data('field');
    let value = $(this).text().trim();

    // Auto-delete if School is empty or N/A
    if (field === 'school' && (value === '' || value.toLowerCase() === 'n/a')) {
      if (confirm('School name is empty or invalid. Delete this entry?')) {
        $.post('process.php', { op: 'delete', id: id }, loadTable);
      }
      return;
    }

    $.post('process.php', {
      op: 'inline_update',
      id: id,
      field: field,
      value: value
    }, function(response) {
      if (response.trim() === 'ok') {
        loadTable();
      } else {
        alert('Error updating: ' + response);
      }
    });
  });

  // Delete button
  $(document).on('click', '.deleteBtn', function() {
    let id = $(this).data('id');
    if (confirm("Delete this entry?")) {
      $.post('process.php', { op: 'delete', id: id }, loadTable);
    }
  });
});
