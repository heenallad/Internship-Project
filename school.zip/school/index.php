<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>School Work Tracking System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script>
    // Disable Right-Click
    document.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    });

    // Disable DevTools Shortcut Keys
    document.addEventListener("keydown", function(e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
      }
    });

    // Optional: Detect if DevTools is open (basic)
    setInterval(function() {
      if (window.outerHeight - window.innerHeight > 200) {
        document.body.innerHTML = "<h1>Inspect Disabled</h1>";
      }
    }, 1000);
  </script>
  <style>
    body {
      background-color: #f8f9fa;
    }

    .hero {
      background: url('home.jpg') no-repeat center center;
      background-size: cover;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: bold;
    }

    .hero p {
      font-size: 1.5rem;
    }

    .btn-custom {
      background-color: #007bff;
      color: white;
      padding: 0.75rem 1.5rem;
      font-size: 1.25rem;
      border-radius: 0.5rem;
      transition: background-color 0.3s;
    }

    .btn-custom:hover {
      background-color: #0056b3;
    }
  </style>
</head>

<body>

  <!-- Hero Section -->
  <div class="hero">
    <div class="text-center">
      <h1>Welcome to the School Work Tracking System</h1>
      <p>Efficiently manage and track school assignments and tasks.</p>
      <a href="login.php" class="btn btn-custom">Login</a>
    </div>
  </div>

  <!-- Bootstrap & Font Awesome -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>

</html>