<?php session_start();
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'user') {
        header('Location:user/index.php');
        exit;
    } elseif ($_SESSION['role'] === 'admin') {
        header('Location:admin/index.php');
        exit;
    }
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db.php';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username=?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role'];
            if ($row['role'] === 'user') {
                header('Location:user/index.php');
                exit;
            } elseif ($row['role'] === 'admin') {
                header('Location:admin/index.php');
                exit;
            }
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <style>
  /* Page Title */
  h2 {
    text-align: center;
    font-size: 30px;
    font-weight: bold;
    margin-bottom: 10px;
  }

  /* Login Heading */
  h3.opacity {
    font-size: 20px;
    text-align: center;
    margin-bottom: -10px;
    margin-top: -10px;
  }

  /* Submit & Close Buttons (Unified Appearance) */
  button.opacity,
  .opacitya a {
    background-color: red;
    color: black;
    border: none;
    padding: 10px 40px;       /* Wider appearance */
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
    display: inline-block;
    cursor: pointer;
    font-family: inherit;
    font-size: 20px;
    transition: background-color 0.3s ease;
    min-width: 300px;
    min-height: 45px;
    margin-top: -5px;
  }

  /* Hover effect */
  .opacitya a:hover{
    background-color: darkred;
  }

  /* CLOSE button container alignment */
  .opacitya {
    display: flex;
    justify-content: center;
    margin-top: -20px;           /* Less spacing below SUBMIT */
    margin-left: 10px;
  }
</style>
    <link rel="stylesheet" href="login.css">
     <script>
    // Disable Right-Click
    document.addEventListener("contextmenu", function (e) {
      e.preventDefault();
    });

    // Disable DevTools Shortcut Keys
    document.addEventListener("keydown", function (e) {
      if (
        e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
      }
    });

    // Optional: Detect if DevTools is open (basic)
    setInterval(function () {
      if (window.outerHeight - window.innerHeight > 200) {
        document.body.innerHTML = "<h1>Inspect Disabled</h1>";
      }
    }, 1000);
    
  </script>
</head>
<body> 
    <section class="container"> 
        <div class="login-container"> 
            <h2>School Task Management</h2> 
            <div class="circle circle-one"></div> 
            <div class="form-container"> 
                <h3 class="opacity">LOGIN</h3> 
                <form action="" method="post"> 
                    <input type="text" placeholder="USERNAME" name="username" required /> 
                    <input type="password" placeholder="PASSWORD" name="password" required /> 
                    <button class="opacity">SUBMIT</button> 
                    <div class="opacitya"><a href="index.php">CLOSE</a></div>
                </form> </div> <div class="circle circle-two">
            </div> 
        </div> 
        <div class="theme-btn-container"></div> 
    </section> 
</body>
</html>