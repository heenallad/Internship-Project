<?php
include 'db.php';

$username = 'admin';
$password = password_hash('admin123', PASSWORD_DEFAULT);
$role = 'admin';

$conn->query("INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')");
echo "Admin user created.";
?>