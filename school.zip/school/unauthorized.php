<!DOCTYPE html>
<html>
<head>
    <title>Unauthorized Access</title>
</head>
<body>
    <h2 style="color:red; text-align:center;">403 Forbidden</h2>
    <p style="text-align:center;">You do not have permission to access this page.</p>
    <div style="text-align:center;"><a href="index.php">Go back</a></div>
</body>
</html>
